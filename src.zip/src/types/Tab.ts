export interface Tab {
  id: string;
  title: string;
  content: string;
}
